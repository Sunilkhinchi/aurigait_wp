<?php 
/**
 * Plugin Name: My plugin
 * Description: this is my first plugin.
 * Version: 1.7.2
 * Author: Sunil Khinchi
 * Author URI: sunil.khinchi.com
 */

 if(!defined('ABSPATH')){
    header("Location: /AurigaCus");
    die("");
 }

function my_plugin_activation(){
    global $wpdb,$table_prefix;
    $wp_emp = $table_prefix.'emp';
    $query = "CREATE TABLE IF NOT EXISTS `$wp_emp` ( `id` INT NOT NULL AUTO_INCREMENT , `name`
               VARCHAR(50) NOT NULL , `email` VARCHAR(100) NOT NULL , `phone` VARCHAR(15) NOT NULL , `status` BOOLEAN NOT NULL ,
                PRIMARY KEY (`id`)) ENGINE = InnoDB;";
     $wpdb->query($query); 

   // $query = "INSERT INTO `$wp_emp` ( `name`, `email`, `status`) VALUES ( 'sunil khinchi', 'sunilkhhinchi543@gmail.com', 1);";
   // $wpdb->query($query); 
     $data = array(
           'name' => 'sunil',
           'email'=>'mp17sunil97@gmail.com',
           'phone'=> "9999888833",
           'status'=>1
     );
      $wpdb->insert($wp_emp, $data);
 }

 register_activation_hook( __FILE__, 'my_plugin_activation');

function my_plugin_deactivation(){
    global $wpdb,$table_prefix;
    $wp_emp = $table_prefix.'emp';
    $query = "TRUNCATE `$wp_emp`";
    $wpdb->query($query);
    
}
register_deactivation_hook( __FILE__, 'my_plugin_deactivation' );

 function shortcode_funtion($atts){
   $atts = array_change_key_case($atts,CASE_LOWER);
   $atts = shortcode_atts(array(
      'massage'=> 'defualt massage',
      'age'=>18,
      'type'=> 'img_gallery'
   ),$atts);
   
   // include 'notice.php';
   // include 'img_gallery.php';
   include $atts['type'].'.php';
  
//   return $atts['massage'] ." test ". $atts['age'] ;
 }

 add_shortcode('first_shortcode','shortcode_funtion');


 add_action('wp_enqueue_scripts','my_custom_scripts');
 function my_custom_scripts(){

   $path_js = plugins_url('js/main.js',__FILE__);
   $path_style = plugins_url('css/style.css',__FILE__);
   $dep = array('jquery',);
   $ver_js = filemtime(plugin_dir_path(__FILE__).'js/main.js');
   $ver_style = filemtime(plugin_dir_path(__FILE__).'js/main.js');
   $is_login = is_user_logged_in() ? 1 : 0;

   wp_enqueue_style('my-custom-style',$path_style, '', $ver_style,'all' );
   wp_enqueue_script('my-custom-js', $path_js ,$dep ,$ver_js,true);
   wp_add_inline_script('my-custom-js','var is_login = '.$is_login.';',' ');

 }

function youtube_fun(){

}

 add_shortcode('youtube','youtube_fun');








