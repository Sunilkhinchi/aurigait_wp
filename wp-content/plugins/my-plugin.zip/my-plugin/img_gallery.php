<div>
    <img src="https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg" alt="" class="w-100">
    <img src="https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg" alt="" class="w-100">
    <img src="https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg" alt="" class="w-100">
    <img src="https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg" alt="" class="w-100">
</div>