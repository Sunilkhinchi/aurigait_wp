<?php 

/* silence is golden*/